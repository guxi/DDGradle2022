package edu.wust.gradleinitSpring;

public class config {

}
